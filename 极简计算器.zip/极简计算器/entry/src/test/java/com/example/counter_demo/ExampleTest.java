package com.example.counter_demo;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
